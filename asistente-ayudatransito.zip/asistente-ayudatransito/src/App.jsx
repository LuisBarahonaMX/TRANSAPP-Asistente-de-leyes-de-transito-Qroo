// src/App.jsx
import React, { useState, useEffect, useRef } from 'react';

function App() {
  const [question, setQuestion] = useState('');
  const [answer, setAnswer] = useState('');
  const [error, setError] = useState('');
  const inputRef = useRef();

  const handleAsk = async () => {
    if (!question.trim()) return;
    setError('');
    setAnswer('');
    try {
      const resp = await fetch('http://localhost:3333/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ question }),
      });
      if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
      const data = await resp.json();
      setAnswer(data.answer);

      if ('speechSynthesis' in window) {
        const utter = new SpeechSynthesisUtterance(data.answer);
        utter.lang = 'es-MX';
        window.speechSynthesis.speak(utter);
      }
    } catch (err) {
      console.error(err);
      setError(err.message);
    }
  };

  const handleSpeak = () => {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) {
      alert('Tu navegador no soporta reconocimiento de voz');
      return;
    }
    const recognition = new SpeechRecognition();
    recognition.lang = 'es-MX';
    recognition.start();
    recognition.onresult = (event) => {
      const transcript = event.results[0][0].transcript;
      setQuestion(transcript);
    };
    recognition.onerror = (e) => {
      console.error('Error de reconocimiento de voz:', e);
    };
  };

  // Activar envío con Enter
  useEffect(() => {
    const handleKeyDown = (e) => {
      if (e.key === 'Enter') handleAsk();
    };
    const input = inputRef.current;
    input.addEventListener('keydown', handleKeyDown);
    return () => input.removeEventListener('keydown', handleKeyDown);
  }, []);

  return (
    <div style={{
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      minHeight: '100vh',
      padding: '2rem',
      fontFamily: 'Segoe UI, Roboto, sans-serif',
      backgroundColor: '#e6f0ff',
      color: '#003366',
      textAlign: 'center'
    }}>
      <h1 style={{ color: '#003366' }}>Asistente de Tránsito</h1>

      <input
        ref={inputRef}
        type="text"
        value={question}
        onChange={(e) => setQuestion(e.target.value)}
        placeholder="Escribe tu consulta..."
        style={{
          width: '100%',
          maxWidth: '500px',
          padding: '0.75rem',
          fontSize: '1.1rem',
          borderRadius: '6px',
          border: '1px solid #66a3ff',
          marginBottom: '1rem'
        }}
      />

      <div style={{ marginBottom: '1rem' }}>
        <button
          onClick={handleAsk}
          style={{
            padding: '0.6rem 1.2rem',
            marginRight: '1rem',
            backgroundColor: '#3385ff',
            color: '#fff',
            border: 'none',
            borderRadius: '5px',
            fontSize: '1rem',
            cursor: 'pointer'
          }}
        >
          Enviar
        </button>
        <button
          onClick={handleSpeak}
          style={{
            padding: '0.6rem 1.2rem',
            backgroundColor: '#99ccff',
            color: '#003366',
            border: 'none',
            borderRadius: '5px',
            fontSize: '1rem',
            cursor: 'pointer'
          }}
        >
          Hablar
        </button>
      </div>

      <h2 style={{ marginBottom: '0.5rem' }}>Respuesta:</h2>
      {error ? (
        <p style={{ color: 'red' }}>Error: {error}</p>
      ) : (
        <p style={{
          maxWidth: '600px',
          background: '#ffffff',
          padding: '1rem',
          borderRadius: '8px',
          boxShadow: '0 0 10px rgba(0,0,0,0.1)',
          whiteSpace: 'pre-wrap'
        }}>{answer}</p>
      )}
    </div>
  );
}

export default App;
